from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import traceback


def setup_driver():
    options = webdriver.ChromeOptions()

    # ✅ Use cloned profile so you stay logged in
    options.add_argument(r"--user-data-dir=D:\selenium_profile_swiggy")
    options.add_argument(r"--profile-directory=Default")

    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )
    return driver


def main(location="Anand", dish="Pizza"):
    driver = setup_driver()
    wait = WebDriverWait(driver, 20)

    try:
        # STEP 1 – Open Swiggy homepage
        driver.get("https://www.swiggy.com/")
        print("✅ Swiggy opened")

        # STEP 2 – Enter delivery location
        try:
            pin_input = wait.until(EC.element_to_be_clickable((By.ID, "location")))
            pin_input.click()
            pin_input.clear()
            pin_input.send_keys(location)
            time.sleep(2)

            # Pick first suggestion
            first_suggestion = wait.until(EC.element_to_be_clickable((
                By.XPATH, "//span[contains(text(),'" + location + "')]"
            )))
            first_suggestion.click()
            print(f"📍 Location set: {location}")
        except Exception as e:
            print("⚠️ Location input failed")
            raise e
        time.sleep(3)

        # STEP 3 – Search for dish
        try:
            search_box = wait.until(EC.element_to_be_clickable((
                By.XPATH, "//input[contains(@placeholder,'Search for restaurants')]"
            )))
            search_box.click()
            search_box.clear()
            search_box.send_keys(dish)
            search_box.send_keys(Keys.ENTER)
            print(f"🔍 Searching for: {dish}")
        except Exception as e:
            print("⚠️ Search failed")
            raise e
        time.sleep(4)

        # STEP 4 – Open first restaurant
        try:
            first_restaurant = wait.until(EC.element_to_be_clickable((
                By.XPATH, "(//a[contains(@href,'/restaurants/')])[1]"
            )))
            first_restaurant.click()
            print("🍴 First restaurant opened")
        except Exception as e:
            print("⚠️ Couldn’t open restaurant")
            raise e
        time.sleep(4)

        # Switch if it opened new tab
        if len(driver.window_handles) > 1:
            driver.switch_to.window(driver.window_handles[-1])

        # STEP 5 – Add first item
        try:
            add_btn = wait.until(EC.element_to_be_clickable((
                By.XPATH, "(//button[contains(text(),'Add') or contains(text(),'ADD')])[1]"
            )))
            add_btn.click()
            print("🛒 Item added to cart")
        except Exception as e:
            print("⚠️ Add to cart failed")
            raise e
        time.sleep(3)

        # STEP 6 – Go to cart/checkout
        try:
            cart_btn = wait.until(EC.element_to_be_clickable((
                By.XPATH, "//span[contains(text(),'Checkout')] | //a[contains(@href,'checkout')]"
            )))
            cart_btn.click()
            wait.until(EC.url_contains("checkout"))
            print("✅ Reached checkout page")
        except Exception as e:
            print("⚠️ Couldn’t reach checkout")
            raise e
        time.sleep(5)

        # STEP 7 – Payment (⚠️ Manual)
        print("💳 Proceed to payment manually (Swiggy blocks auto-payment).")

    except Exception as e:
        print("❌ Error during automation:")
        print(traceback.format_exc())
        driver.save_screenshot("swiggy_debug.png")
        with open("swiggy_page.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)

    finally:
        driver.quit()
        print("👋 Browser closed")


if __name__ == "__main__":
    main(location="Anand", dish="Pizza")
