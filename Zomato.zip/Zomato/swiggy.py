from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import traceback


def setup_driver():
    options = webdriver.ChromeOptions()

    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )
    return driver


def main():
    driver = setup_driver()
    wait = WebDriverWait(driver, 30)

    try:
        # STEP 1 – Open Swiggy homepage
        driver.get("https://www.swiggy.com/search")
        print("✅ Swiggy opened")

        # STEP 2 – Login manually
        print("📱 Please login with your phone and OTP manually...")
        input("👉 Press ENTER here once you are logged in successfully: ")

        # STEP 3 – Set location Anand, Gujarat
        try:
            pin_input = wait.until(EC.element_to_be_clickable((By.ID, "location")))
            pin_input.click()
            pin_input.clear()
            pin_input.send_keys("Anand, Gujarat, India")
            time.sleep(2)

            first_suggestion = wait.until(EC.element_to_be_clickable((
                By.XPATH, "//span[contains(text(),'Anand')]"
            )))
            first_suggestion.click()
            print("📍 Location set: Anand, Gujarat")
        except Exception:
            print("⚠️ Location input skipped (maybe already set)")

        time.sleep(4)

        # STEP 4 – Go directly to search page for "Radhe Dhokla"
        driver.get("https://www.swiggy.com/search?query=radhe%20dhokla")
        print("🔍 Searching Radhe Dhokla via direct URL")
        time.sleep(4)

        # STEP 5 – Open Radhe Dhokla restaurant (pick link containing the name)
        try:
            radhe_link = wait.until(EC.element_to_be_clickable((
                By.XPATH, "//a[contains(@href,'/restaurants/') and contains(.,'Radhe Dhokla')]"
            )))
            radhe_link.click()
            print("🍴 Radhe Dhokla opened")
        except Exception as e:
            print("⚠️ Couldn’t open Radhe Dhokla")
            raise e
        time.sleep(4)

        if len(driver.window_handles) > 1:
            driver.switch_to.window(driver.window_handles[-1])

        # STEP 6 – Add first available item
        try:
            add_btn = wait.until(EC.element_to_be_clickable((
                By.XPATH, "(//div[contains(text(),'Add')])[1] | (//button[contains(text(),'Add')])[1]"
            )))
            add_btn.click()
            print("🛒 First item added to cart")
        except Exception as e:
            print("⚠️ Adding item failed")
            raise e
        time.sleep(3)

        # STEP 7 – Go to checkout
        try:
            cart_btn = wait.until(EC.element_to_be_clickable((
                By.XPATH, "//a[contains(@href,'/checkout')]"
            )))
            cart_btn.click()
            wait.until(EC.url_contains("checkout"))
            print("✅ Reached checkout page")
        except Exception as e:
            print("⚠️ Couldn’t reach checkout")
            raise e
        time.sleep(5)

        print("💳 Please complete payment manually.")

    except Exception:
        print("❌ Error during automation:")
        print(traceback.format_exc())
        driver.save_screenshot("swiggy_debug.png")
        with open("swiggy_page.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)

    finally:
        driver.quit()
        print("👋 Browser closed")


if __name__ == "__main__":
    main()
